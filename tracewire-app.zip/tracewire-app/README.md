# Tracewire — Setup Guide

Tracewire is free to use — no billing, no PayFast, no paywall. Auth and the
database still need your own free Supabase project.

## What's new in this version

- **Free to use** — the subscription/paywall layer has been removed entirely.
- **How It Works tab** — step-by-step instructions inside the app for tagging
  and logging cables, visible to any signed-in user.
- **QR code per job** — from any job screen, tap "QR" to get a code linking to
  a public, read-only view of that job's wiring record
  (`yourapp.com/j/[job-id]`). Print it and stick it on the DB board — the next
  electrician can scan it and see the full cable log with no login required.

## 1. Supabase (database + auth) — free

1. Go to supabase.com → New Project.
2. **New setup**: SQL Editor → paste `supabase/schema.sql` → Run.
   **Already had the old (subscription) version running?** → instead run
   `supabase/migration_remove_subscriptions.sql` to drop the subscriptions
   table and update the signup trigger.
3. Settings → API → copy your Project URL, anon key, and service_role key into
   `.env.local` (copy `.env.example` as a starting point). The service_role
   key is powerful — never commit it, never expose it to the browser. It's
   used server-side only, by the public QR job-view API route.

## 2. Local development

```bash
npm install
cp .env.example .env.local   # fill in your real Supabase values
npm run dev
```

Visit localhost:3000 → sign up → you're straight into the app, no payment step.

## 3. Deploy

1. Push this code to a GitHub repo.
2. vercel.com → New Project → import the repo.
3. Add the same environment variables from `.env.local` in Vercel's project
   settings (Settings → Environment Variables).
4. Deploy. Point a custom domain (e.g. tracewire.co.za) once ready — the QR
   codes are generated from `window.location.origin`, so they'll automatically
   use whatever domain the app is running on.

## The QR code / DB board flow, in detail

1. Open any job → tap "QR" → a code appears linking to `/j/[job-id]`.
2. Print it (the Print button triggers your browser's print dialog) and stick
   it to the DB board, ideally laminated or otherwise weatherproofed.
3. Anyone who scans it — with no account and no login — lands on a clean,
   read-only page showing: job/site name, address, contractor, linked COC
   reference, and the full cable log.
4. This is intentionally public once you have the link, since job IDs are
   unguessable UUIDs and the person scanning is physically standing at the
   board. Don't extend the public API route
   (`pages/api/public/job/[id].js`) to expose anything beyond what's already
   there without adding real access control first.

## What's simulated vs. real in the current build

- **Real**: auth, database, job/cable logging, circuit map, printable report,
  QR code generation, public read-only job view.
- **Simulated**: the "Tap to Scan" button — real NFC tag reading needs the Web
  NFC API (Android Chrome only) or a native wrapper. That's the natural next
  build once you're validating this with real electricians.
