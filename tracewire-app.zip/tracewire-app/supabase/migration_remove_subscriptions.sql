-- Only run this if you already ran the OLD schema.sql (the one with PayFast
-- subscriptions) in your Supabase project. If you're setting up fresh, just
-- use schema.sql — you don't need this file at all.

drop trigger if exists on_auth_user_created on auth.users;

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

drop table if exists subscriptions;
