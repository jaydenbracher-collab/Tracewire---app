-- Run this in Supabase → SQL Editor, once, when you first set up your project.

-- Every contractor gets a profile row, created automatically on signup
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  contractor_name text,
  reg_no text,
  created_at timestamptz default now()
);

create table jobs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  name text not null,
  address text not null,
  contractor text,
  reg_no text,
  coc_ref text,
  created_at timestamptz default now()
);

create table cables (
  id uuid default gen_random_uuid() primary key,
  job_id uuid references jobs on delete cascade not null,
  cable_id text not null,        -- e.g. "C-011", generated client-side
  from_point text not null,
  to_point text not null,
  cable_type text not null,
  notes text,
  photo boolean default false,
  created_at timestamptz default now()
);

-- ---------- Row-Level Security: each contractor only ever sees their own data ----------
-- Note: the public QR-code job view (pages/j/[id].js) does NOT go through these
-- policies — it's served by a server API route using the service role key,
-- which deliberately bypasses RLS for that one read-only, unauthenticated view.

alter table profiles enable row level security;
alter table jobs enable row level security;
alter table cables enable row level security;

create policy "Users manage their own profile"
  on profiles for all using (auth.uid() = id);

create policy "Users manage their own jobs"
  on jobs for all using (auth.uid() = user_id);

create policy "Users manage cables on their own jobs"
  on cables for all using (
    exists (select 1 from jobs where jobs.id = cables.job_id and jobs.user_id = auth.uid())
  );

-- Auto-create a profile row whenever someone signs up
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
